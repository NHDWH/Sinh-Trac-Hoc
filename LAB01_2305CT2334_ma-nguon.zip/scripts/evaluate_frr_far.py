import os
import time
from system import AFISSystem
from preprocessing import PreprocessingPipeline

def parse_score(result):
    """Trích xuất điểm số từ kết quả trả về của match_templates."""
    if isinstance(result, tuple):
        return float(result[0])
    if isinstance(result, dict):
        return float(result.get('score', 0.0))
    if isinstance(result, (float, int)):
        return float(result)
    return 0.0

def evaluate_system():
    # Thử nghiệm 3 cấu hình adaptive_block_size
    configs = [
        {"name": "C0 (Mặc định)", "adaptive_block_size": 11},
        {"name": "C1 (Nhỏ)", "adaptive_block_size": 5},
        {"name": "C2 (Lớn)", "adaptive_block_size": 21}
    ]
    
    fingers = [f"1{i:02d}" for i in range(1, 11)]  # 10 ngón: 101 đến 110
    raw_dir = "data/raw"
    THRESHOLD = 0.35

    print(f"\n{'Cấu hình':<15} | {'FRR (%)':<10} | {'FAR (%)':<10} | {'Sai dạng vân (Pattern)':<25}")
    print("-" * 75)

    for cfg in configs:
        print(f"\n[*] Đang chạy {cfg['name']} (block_size = {cfg['adaptive_block_size']})...")
        system = AFISSystem(db_path=f"tmp_{cfg['adaptive_block_size']}.db")
        system.preprocessor = PreprocessingPipeline(config={"adaptive_block_size": cfg["adaptive_block_size"]})
        
        templates_cache = {}
        
        # Bước A: Trích xuất đặc trưng có in tiến độ
        for finger in fingers:
            for sample in range(1, 5):
                img_name = f"{finger}_{sample}.tif"
                img_path = os.path.join(raw_dir, img_name)
                if os.path.exists(img_path):
                    print(f"    -> Đang trích xuất: {img_name}...", end="\r", flush=True)
                    tpl = system._create_template_from_image(img_path, img_name)
                    templates_cache[img_name] = tpl
                    
        print(f"    -> Đã trích xuất xong đặc trưng! Đang tính toán đối sánh...")

        # Bước B: Đo FRR (30 lượt cùng ngón)
        frr_rejects = 0
        pattern_mismatch_count = 0
        total_genuine = 30
        
        for finger in fingers:
            enroll_tpl = templates_cache.get(f"{finger}_1.tif")
            if not enroll_tpl or not enroll_tpl.minutiae:
                frr_rejects += 3
                continue
                
            for sample in range(2, 5):
                query_tpl = templates_cache.get(f"{finger}_{sample}.tif")
                if not query_tpl or not query_tpl.minutiae:
                    frr_rejects += 1
                    continue
                
                result = system.matcher.match_templates(query_tpl, enroll_tpl)
                score = parse_score(result)
                
                # Bắt lỗi pattern_mismatch khi điểm số bằng 0 tuyệt đối
                if score == 0.0:
                    pattern_mismatch_count += 1
                    frr_rejects += 1
                elif score < THRESHOLD:
                    frr_rejects += 1
                    
        frr_percent = (frr_rejects / total_genuine) * 100
        
        # Bước C: Đo FAR (30 lượt khác ngón)
        far_accepts = 0
        total_impostor = 30
        
        for i, finger in enumerate(fingers):
            query_tpl = templates_cache.get(f"{finger}_2.tif")
            if not query_tpl or not query_tpl.minutiae:
                continue
                
            for j in range(1, 4):
                target_idx = (i + j) % 10
                target_finger = fingers[target_idx]
                target_tpl = templates_cache.get(f"{target_finger}_1.tif")
                
                if not target_tpl or not target_tpl.minutiae:
                    continue
                    
                result = system.matcher.match_templates(query_tpl, target_tpl)
                score = parse_score(result)
                
                if score >= THRESHOLD:
                    far_accepts += 1
                    
        far_percent = (far_accepts / total_impostor) * 100
        
        print(f"--> {cfg['name']:<15} | FRR: {frr_percent:>6.2f}% | FAR: {far_percent:>6.2f}% | Mismatch: {pattern_mismatch_count} lượt")

if __name__ == "__main__":
    start_time = time.time()
    evaluate_system()
    print(f"\nTổng thời gian chạy hoàn tất: {(time.time() - start_time)/60:.2f} phút")