import os
import numpy as np
from system import AFISSystem

def extract_and_export():
    system = AFISSystem(db_path="tmp_batch.db")
    
    raw_dir = "data/raw"
    export_dir = "data/minutiae"
    if not os.path.exists(export_dir):
        os.makedirs(export_dir)
        
    minutiae_counts = []
        
    for filename in os.listdir(raw_dir):
        if filename.endswith(('.png', '.tif')):
            img_path = os.path.join(raw_dir, filename)
            
            # Đặt template_id dựa theo tên file (bỏ đuôi mở rộng)
            template_id = os.path.splitext(filename)[0]
            
            # Truyền đủ 2 tham số: img_path và template_id
            template = system._create_template_from_image(img_path, template_id)
            
            if template and template.minutiae:
                minutiae_list = template.minutiae
                minutiae_counts.append(len(minutiae_list))
                
                data_list = []
                for m in minutiae_list:
                    # Chuẩn hóa về [0, 1] do ảnh đã bị resize về kích thước 500x500
                    norm_x = m.x / 500.0
                    norm_y = m.y / 500.0
                    theta = m.orientation  # Góc minutia là orientation
                    
                    data_list.append([norm_x, norm_y, theta])
                    
                data = np.array(data_list)
                
                out_path = os.path.join(export_dir, filename.replace('.tif', '.npy').replace('.png', '.npy'))
                np.save(out_path, data)
                print(f"Xử lý thành công: {filename} - {len(minutiae_list)} minutiae")
            else:
                print(f"Bỏ qua: {filename} (Không trích xuất được minutiae)")
                
    if minutiae_counts:
        print("\n--- THỐNG KÊ MINUTIAE (CHO MỤC 5 BÁO CÁO) ---")
        print(f"Nhỏ nhất (Min): {np.min(minutiae_counts)}")
        print(f"Trung vị (Median): {np.median(minutiae_counts)}")
        print(f"Lớn nhất (Max): {np.max(minutiae_counts)}")

if __name__ == "__main__":
    extract_and_export()